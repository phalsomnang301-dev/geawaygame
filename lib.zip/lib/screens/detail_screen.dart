import 'package:cached_network_image/cached_network_image.dart';
import 'package:flutter/material.dart';
import 'package:flutter_assiment/models/giveaway_detail.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:flutter_assiment/providers/giveaway_provider.dart';

class DetailScreen extends ConsumerStatefulWidget {
  const DetailScreen({super.key});

  @override
  ConsumerState<DetailScreen> createState() => _DetailScreenState();
}

class _DetailScreenState extends ConsumerState<DetailScreen> {
  @override
  Widget build(BuildContext context) {
    final id = ModalRoute.of(context)?.settings.arguments as int;
    final detailAsycn = ref.watch(mealDetailProvider(id));
    return Scaffold(
      appBar: AppBar(
        title: Text(
          "Detail Screen $id",
          style: TextStyle(fontWeight: FontWeight.bold),
        ),
      ),

      body: RefreshIndicator(
        onRefresh: () async {
          ref.invalidate(mealDetailProvider);
        },
        child: Center(
          child: detailAsycn.when(
            data: (item) {
              return _buildListView(item);
            },
            error: (e, s) {
              debugPrint("Error : ${e.toString()}");
              debugPrint("TrackTrace : ${s.toString()}");
              return Text("Error : ${e.toString()}");
            },
            loading: () {
              return CircularProgressIndicator();
            },
          ),
        ),
      ),
    );
  }


  Widget _buildListView(GiweawayDetail item) {
    return ListView(
      physics: const AlwaysScrollableScrollPhysics(),
      children: [
        Card(
          child: Padding(
            padding: const .all(8.0),
            child: ClipRRect(
              borderRadius: .circular(8),
              child: CachedNetworkImage(
                imageUrl:item.thumbnail,
                fit:BoxFit.cover,
              ),
            ),
          ),
        ),
        Card(
          child: ListTile(
            leading: Icon(Icons.title),
            title: Text(item.title),
          ),
        ),
        Card(
          child: ListTile(
            leading: Icon(Icons.light),
            title: Text(item.description),
          ),
        ),
        Card(
          child: ListTile(
            leading: Icon(Icons.category),
            title: Text(item.worth),
          ),
        ),
        Card(
          child: ListTile(
            leading: Icon(Icons.language),
            title: Text(item.instructions),
          ),
        ),

      ],
    );
  }
}
